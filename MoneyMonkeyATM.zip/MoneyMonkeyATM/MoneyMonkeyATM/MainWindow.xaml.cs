﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace MoneyMonkeyATM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        public MainWindow()
        {
            InitializeComponent();
            DispatcherTimer ViewServerHandler = new DispatcherTimer();

            ViewServerHandler.Interval = TimeSpan.FromMilliseconds(1000);
            ViewServerHandler.Tick += ViewServerHandler_tick;
            ViewServerHandler.Start();
            MainViewServer.ViewServer_create();

            foreach (UIElement Button in UpperMenuGrid.Children)
            {
                if (Button is Button)
                {
                    ((Button)Button).Click += TaskbarClick;
                }
            }
            PageContainer.Navigate(new System.Uri("Pages/LandingPage.xaml", UriKind.RelativeOrAbsolute));
        }

        void ViewServerHandler_tick(object sender, EventArgs e)
        {
            MainViewServer.GetViewserverFile();
            if (MainViewServer.AllowViewChange())
            {
                PageContainer.Navigate(new System.Uri(MainViewServer.NavigateTo(), UriKind.RelativeOrAbsolute));
            }

        }


        private void TaskbarClick(object sender, RoutedEventArgs e)
        {
            switch (((Button)e.OriginalSource).Name)
            {
                case "Minimize":
                    WindowState = WindowState.Minimized;
                    break;
                case "Close":
                    Shutdown();
                    break;
            }
        }

        private void Shutdown()//This will be used in future to secure port closing, saving all the setings and safe app shutdown
        {
            App.Current.Shutdown();
        }

        private void DragDropHandler(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

    }
}
