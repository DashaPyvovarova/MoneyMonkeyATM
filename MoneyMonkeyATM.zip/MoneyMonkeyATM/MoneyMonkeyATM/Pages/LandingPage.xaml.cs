﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for LandingPage.xaml
    /// </summary>
    public partial class LandingPage : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        Class.User UserEntity = new Class.User();
        Class.ATM ATMEntity = new Class.ATM();
        public LandingPage()
        {
            InitializeComponent();
            MainViewServer.ViewServer_create();
            ATMEntity.Atm_CreateInstance();
        }

        private void CheckCredsAndLogin(object sender, EventArgs e)
        {
            if (Login.Text.Contains("admin") && Password.Text.Contains("admin"))
            {
                LoginAdmin();
            }
            else
                LoginUser();
        }
        private void CreateNewUser(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(4);
        }

        void LoginAdmin()
        {
            ATMEntity.CreateSession("Administrator");
            MainViewServer.SetDestionationAndNavigate(1);
            ATMEntity.CreateLog("Admin logged in");
        }

        void LoginUser()
        {
            if (UserEntity.Login(Login.Text, Password.Text) == 0)
            {
                ATMEntity.CreateSession(Login.Text);
                MainViewServer.SetDestionationAndNavigate(6);
                ATMEntity.CreateLog(UserEntity.Name + " logged in");
            }
            else
                Login.BorderBrush = Brushes.Red;
                Password.BorderBrush = Brushes.Red;
        }


    }
}
