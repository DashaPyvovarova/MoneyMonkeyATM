﻿using MoneyMonkeyATM.Class;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for UserPage.xaml
    /// </summary>
    public partial class UserPage : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        Class.ATM ATMEntity = new Class.ATM();
        Class.User UserEntity = new Class.User();
        public UserPage()
        {
            InitializeComponent();
            MainViewServer.ViewServer_create();
            ATMEntity.Atm_CreateInstance();
            RestoreSession();
        }

        private void RestoreSession()
        {
            string SessionKey = ATMEntity.GetSession();
            if (SessionKey != null)
            {
                UserEntity.InitiateUser(SessionKey);
                PopulateData();
            }
            else
                MainViewServer.SetDestionationAndNavigate(0);
        }

        private void PopulateData()
        {
            Greetings.Text = "Ласкаво просимо, " + UserEntity.Name;
            UAHbalance.Text = UserEntity.UAH.ToString();
            USDballance.Text = UserEntity.USD.ToString();
            EURballance.Text = UserEntity.EUR.ToString();
            cardNum.Text = UserEntity.CardNumber;
            CardType.Text = UserEntity.CardType;
        }

        private void OpenWithdraw(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(7);
        }
        private void OpenInfill(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(3);
        }
        private void OpenTransfer(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(5);
        }
        private void OpenATMStats(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(2);
        }
        private void OpenChangeAccount(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(4);
        }

        private void DeleteAccount(object sender, EventArgs e)
        {
            UserEntity.DeleteAccount();
            ATMEntity.ExpireSession();
            MainViewServer.SetDestionationAndNavigate(0);
        }
        private void LogOut(object sender, EventArgs e)
        {
            ATMEntity.ExpireSession();
            MainViewServer.SetDestionationAndNavigate(0);
        }
    }
}
