﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for TransferMoney.xaml
    /// </summary>
    public partial class TransferMoney : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        public TransferMoney()
        {
            InitializeComponent();
            MainViewServer.ViewServer_create();
        }

        private void LogOut(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(6);
        }
    }
}
