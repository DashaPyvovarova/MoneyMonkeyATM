﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for FillIn.xaml
    /// </summary>
    public partial class FillIn : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        Class.ATM ATMEntity = new Class.ATM();
        Class.User UserEntity = new Class.User();
        public FillIn()
        {
            InitializeComponent();
            MainViewServer.ViewServer_create();
            ATMEntity.Atm_CreateInstance();
            PopulateData();
            RestoreSession();
        }

        private void RestoreSession()
        {
            string SessionKey = ATMEntity.GetSession();
            if (SessionKey != null)
            {
                UserEntity.InitiateUser(SessionKey);
            }
            else
                MainViewServer.SetDestionationAndNavigate(6);
        }

        private void PopulateData()
        {
            AvailableBalance.Text = (ATMEntity.max_UAH_Amount - ATMEntity.UAH_Amount).ToString() + "UAH | " + (ATMEntity.max_USD_Amount - ATMEntity.USD_Amount).ToString() + "USD | " + (ATMEntity.max_EUR_Amount - ATMEntity.EUR_Amount).ToString() + "EUR | " ;
        }

        private void IngestMoney(object sender, EventArgs e)
        {
            ATMEntity.IngestCurrency(CurrencyType.Text, Convert.ToInt32(FillCount.Text));
            UserEntity.IngestMoney(CurrencyType.Text, Convert.ToInt32(FillCount.Text));
            ATMEntity.CreateLog(UserEntity.Name + " ingested " + Convert.ToInt32(FillCount.Text) + CurrencyType.Text + " to their account");
            PopulateData();
        }

        private void LogOut(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(6);
        }
    }
}
