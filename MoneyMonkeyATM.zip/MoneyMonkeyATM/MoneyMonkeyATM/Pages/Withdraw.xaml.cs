﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for Withdraw.xaml
    /// </summary>
    public partial class Withdraw : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        Class.ATM ATMEntity = new Class.ATM();
        Class.User UserEntity = new Class.User();
        public Withdraw()
        {
            InitializeComponent();
            MainViewServer.ViewServer_create();
            ATMEntity.Atm_CreateInstance();
            RestoreSession();
        }

        private void RestoreSession()
        {
            string SessionKey = ATMEntity.GetSession();
            if (SessionKey != null)
            {
                UserEntity.InitiateUser(SessionKey);
                PopulateData();
            }
            else
                MainViewServer.SetDestionationAndNavigate(6);
        }

        private void PopulateData()
        {
            AvailableBalance.Text = UserEntity.UAH.ToString() + "UAH | " + UserEntity.USD.ToString() + "USD | " + UserEntity.EUR.ToString() + "EUR";
            InATM.Text = ATMEntity.UAH_Amount.ToString() + "UAH | " + ATMEntity.USD_Amount.ToString() + "USD | " + ATMEntity.EUR_Amount.ToString() + "EUR";
        }

        private void WithdrawMoney(object sender, EventArgs e)
        {
            if (UserEntity.WithdrawMoney(CurrencyType.Text, Convert.ToInt32(CurrencyCount.Text)) == 0)
            {
                ATMEntity.WithdrawMoney(CurrencyType.Text, Convert.ToInt32(CurrencyCount.Text));
                ATMEntity.CreateLog(UserEntity.Name + " withdrawed " + Convert.ToInt32(CurrencyCount.Text) + CurrencyType.Text + " to their account");
                PopulateData();
            }
        }

        private void LogOut(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(6);
        }
    }
}
