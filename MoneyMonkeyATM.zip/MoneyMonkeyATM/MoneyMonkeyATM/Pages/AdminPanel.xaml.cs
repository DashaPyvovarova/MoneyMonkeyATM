﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        Class.ATM ATMEntity = new Class.ATM();
        public AdminPanel()
        {
            InitializeComponent();
            MainViewServer.ViewServer_create();
            ATMEntity.Atm_CreateInstance();
            PopulateData();
            PopulateLogs();
        }

        private void PopulateData()
        {
            UAHbalance.Text = ATMEntity.UAH_Amount.ToString() + "/" + ATMEntity.max_UAH_Amount.ToString();
            USDbalance.Text = ATMEntity.USD_Amount.ToString() + "/" + ATMEntity.max_USD_Amount.ToString();
            EURbalance.Text = ATMEntity.EUR_Amount.ToString() + "/" + ATMEntity.max_EUR_Amount.ToString();
        }

        private void PopulateLogs()
        {
            ATMLogs.Text = ATMEntity.GetLog();
        }

        private void IngestMoney(object sender, EventArgs e)
        {
            ATMEntity.IngestCurrency(CurrencyType.Text, Convert.ToInt32(FillCount.Text));
            PopulateData();
            ATMEntity.CreateLog("Admin ingested " + Convert.ToInt32(FillCount.Text) + CurrencyType.Text + " to the ATM");
            PopulateLogs();
        }

        private void EjectMoney(object sender, EventArgs e)
        {
            ATMEntity.WithdrawMoney(WithdrawCurrencyType.Text, Convert.ToInt32(WithdrawCount.Text));
            PopulateData();
            ATMEntity.CreateLog("Admin withdrawed " + Convert.ToInt32(WithdrawCount.Text) + CurrencyType.Text + " from the ATM");
            PopulateLogs();
        }

        private void LogOut(object sender, EventArgs e)
        {
            ATMEntity.ExpireSession();
            MainViewServer.SetDestionationAndNavigate(0);
            ATMEntity.CreateLog("Admin logged out");
        }
    }
}
