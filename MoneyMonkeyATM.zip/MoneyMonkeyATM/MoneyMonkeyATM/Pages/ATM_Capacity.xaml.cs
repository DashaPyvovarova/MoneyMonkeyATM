﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for ATM_Capacity.xaml
    /// </summary>
    public partial class ATM_Capacity : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        Class.ATM ATMEntity = new Class.ATM();
        public ATM_Capacity()
        {
            InitializeComponent();
            MainViewServer.ViewServer_create();
            ATMEntity.Atm_CreateInstance();
            DisplayATMCapacity();
        }

        private void DisplayATMCapacity()
        {
            UAHbalance.Text = ATMEntity.UAH_Amount.ToString() + "/" + ATMEntity.max_UAH_Amount.ToString();
            USDbalance.Text = ATMEntity.USD_Amount.ToString() + "/" + ATMEntity.max_USD_Amount.ToString();
            EURbalance.Text = ATMEntity.EUR_Amount.ToString() + "/" + ATMEntity.max_EUR_Amount.ToString();
        }

        private void LogOut(object sender, EventArgs e)
        {
            MainViewServer.SetDestionationAndNavigate(6);
        }
    }
}
