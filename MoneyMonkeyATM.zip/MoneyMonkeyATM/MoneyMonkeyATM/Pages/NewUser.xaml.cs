﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MoneyMonkeyATM.Pages
{
    /// <summary>
    /// Interaction logic for NewUser.xaml
    /// </summary>
    public partial class NewUser : Page
    {
        Class.ViewServer MainViewServer = new Class.ViewServer();
        Class.ATM ATMEntity = new Class.ATM();
        Class.User UserEntity = new Class.User();
        public NewUser()
        {
            MainViewServer.ViewServer_create();
            InitializeComponent();
            ATMEntity.Atm_CreateInstance();
            OnStartup();
        }

        private void OnStartup()//Check session if user is logged in or not
        {
            string sessiontoken = ATMEntity.GetSession();
            if (sessiontoken != null)
            {
                UserEntity.InitiateUser(sessiontoken);
                PopulateExistingUser();
            }
        }

        private void PopulateExistingUser()
        {
            Name.Text = UserEntity.Name;
            Surname.Text = UserEntity.Surname;
            GivenName.Text = UserEntity.GivenName;
            BirthDate.Text = UserEntity.DateOfBirth;
            PhonePrompt.Text = UserEntity.Phone;
            EmailPrompt.Text = UserEntity.LoginEmail;
            CardType.SelectedItem = UserEntity.CardType;
            CardNumber.Text = UserEntity.CardNumber;
        }

        private void CreateUser(object sender, EventArgs e)
        {
            CreateNewUser();
        }

        private void Reject(object sender, EventArgs e)
        {
            ATMEntity.ExpireSession();
            MainViewServer.SetDestionationAndNavigate(0);
        }


        void CreateNewUser()
        {
            //Check whether mandatory fields are populated
            if (EmailPrompt.Text.Length > 0) {
                if (PasswordPrompt.Text.Length > 0)
                {
                    if (ConfirmPasswordPrompt.Text.Length > 0)
                    {
                        if (PasswordPrompt.Text == ConfirmPasswordPrompt.Text)
                        {
                            if (ATMEntity.GetSession() != null)
                            {
                                UserEntity.UpdateUser(EmailPrompt.Text, PasswordPrompt.Text);
                                MainViewServer.SetDestionationAndNavigate(6);
                            }
                            else
                                UserEntity.CreateNewUser(CardType.Text, CardNumber.Text, Name.Text, Surname.Text, GivenName.Text, BirthDate.Text, EmailPrompt.Text, PhonePrompt.Text, PasswordPrompt.Text);
                                MainViewServer.SetDestionationAndNavigate(6);
                                ATMEntity.CreateSession(EmailPrompt.Text);
                        }
                        else
                        {
                            PasswordPrompt.BorderBrush = Brushes.Red;
                            ConfirmPasswordPrompt.BorderBrush = Brushes.Red;
                        }
                    }
                    else
                        ConfirmPasswordPrompt.BorderBrush = Brushes.Red;
                }
                else
                    PasswordPrompt.BorderBrush = Brushes.Red;
            }
            else
                EmailPrompt.BorderBrush = Brushes.Red;
                
        }

        private void CardType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Random random = new Random();
            if(CardType.Text == "MasterCard")
            {
                CardNumber.Text = "4111 " + "11" + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + " " + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + " " + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString();
            }
            else
            {
                CardNumber.Text = "5168 " + "11" + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + " " + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + " " + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString() + random.Next(0, 9).ToString();
            }
        }

    }
}
