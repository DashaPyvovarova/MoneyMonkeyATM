﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Diagnostics.PerformanceData;
using System.Windows.Controls;
using System.Security.Cryptography.X509Certificates;
using System.Windows;

namespace MoneyMonkeyATM.Class
{
    class ViewServer
    {
        private const string _LandingPage_path = "Pages/LandingPage.xaml";      //ViewType 0 
        private const string _admin_path = "Pages/AdminPanel.xaml";             //ViewType 1
        private const string _ATM_capacity_path = "Pages/ATM_capacity.xaml";    //ViewType 2
        private const string _FillIn_path = "Pages/FillIn.xaml";                //ViewType 3
        private const string _NewUser_path = "Pages/NewUser.xaml";              //ViewType 4
        private const string _TransferMoney_path = "Pages/TransferMoney.xaml";  //ViewType 5
        private const string _UserPage_path = "Pages/UserPage.xaml";            //ViewType 6
        private const string _Withdraw_path = "Pages/Withdraw.xaml";            //ViewType 7
        const string ViewServerFile = "ViewServerLogs.viewserver";
        private string project_folder;
        private string ViewServer_folder;
        private string Users_folder;
        private string ATM_info;

        private byte _ViewType = 0;
        private bool _AllowViewChange;
        private string _NavigateTo;

        public void ViewServer_create() //Crates the ViewServer instance
        {
            DirectoryAndFilesCheckup();
        }

        private void DirectoryAndFilesCheckup()//DocumentsFolderSetup
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            ViewServer_folder = project_folder + "\\ViewServer";
            Users_folder = project_folder + "\\Users";
            ATM_info = project_folder + "\\ATM";

            if (!Directory.Exists(project_folder))
            {
                Directory.CreateDirectory(project_folder);
            }
            if (!Directory.Exists(ViewServer_folder))
            {
                Directory.CreateDirectory(ViewServer_folder);
            }
            if (!Directory.Exists(Users_folder))
            {
                Directory.CreateDirectory(Users_folder);
            }
            if (!Directory.Exists(ATM_info))
            {
                Directory.CreateDirectory(ATM_info);
            }
        }

        public bool AllowViewChange()
        {
            return _AllowViewChange;
        }

        public string NavigateTo()
        {
            _AllowViewChange = false;
            File.Delete(ViewServer_folder + "\\" + ViewServerFile);
            return _NavigateTo;
            
        }

        public string ViewByID(byte ID)
        {
            switch (ID)
            {
                case 0:
                    return _LandingPage_path;
                case 1:
                    return _admin_path;
                case 2:
                    return _ATM_capacity_path;
                case 3:
                    return _FillIn_path;
                case 4:
                    return _NewUser_path;
                case 5:
                    return _TransferMoney_path;
                case 6:
                    return _UserPage_path;
                case 7:
                    return _Withdraw_path;
                default:
                    return _LandingPage_path;
            }
        }

        private void UpdateViewserverFile()
        {
            string[] Stats = new string[3];
            Stats[0] = _ViewType.ToString();
            Stats[1] = _AllowViewChange.ToString();
            Stats[2] = _NavigateTo;
            using (StreamWriter SensorData = new StreamWriter(ViewServer_folder + "\\" + ViewServerFile, false))
            {
                for (int i = 0; i < Stats.Length; i++)
                {
                    SensorData.WriteLine(Stats[i]);
                }

            }
        }


        private Stack<string> AllParams = new Stack<string>();
        public void GetViewserverFile()
        {
            try
            {
                string file = ViewServer_folder + "\\" + ViewServerFile;
                if (File.Exists(file))
                {
                    string NewData;
                    using (StreamReader DatabaseFetcher = new StreamReader(file))
                    {
                        while ((NewData = DatabaseFetcher.ReadLine()) != null)
                        {
                            AllParams.Push(NewData);
                        }
                    }

                    _NavigateTo = AllParams.Pop();
                    _AllowViewChange = Convert.ToBoolean(AllParams.Pop());
                    _ViewType = Convert.ToByte(AllParams.Pop());
                    AllParams.Clear();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("ViewServer error, please contact admin");
                File.Delete(ViewServer_folder + "\\" + ViewServerFile);
            }
        }

        public void SetDestionationAndNavigate(byte destination)
        {
            _ViewType = destination;
            _AllowViewChange = true;
            _NavigateTo = ViewByID(destination);
            UpdateViewserverFile();
        }
    }
}
