﻿using MoneyMonkeyATM.Pages;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;

namespace MoneyMonkeyATM.Class
{
    class User
    {
        

        private string project_folder;
        private string users_folder;
        private string user_file;
        private Stack<string> UserData = new Stack<string>();

        #region PublicFunctionsAndVariables
        private int _UAH_amount;
        private int _USD_amount;
        private int _EUR_amount;
        private string _card_number;
        private string _Card_type;
        private string _name;
        private string _surname;
        private string _Given_name;
        private string _date_of_birth;
        private string _login_email;
        private string _phone;

        private string _password;

       public int UAH
       {
            get => _UAH_amount;
            set => _UAH_amount = value;
       }

       public int USD
       {
            get => _USD_amount; 
            set => _USD_amount = value;
       }

            public int EUR
        {
            get => _EUR_amount;
            set => _EUR_amount = value;
        }

            public string CardNumber
        {
            get => _card_number;
            set => _card_number = value;
        }
            public string CardType
        {
            get => _Card_type;
            set => _Card_type = value;
        }
            public string Name
        {
            get => _name;
            set => _name = value;
        }
            public string Surname
        {
            get => _surname;
            set => _surname = value;
        }
            public string GivenName
        {
            get => _Given_name;
            set => _Given_name = value;
        }
            public string DateOfBirth
        {
            get => _date_of_birth;
            set => _date_of_birth = value;
        }
            public string LoginEmail
        {
            get => _login_email;
            set => _login_email = value;
        }
            public string Phone
        {
            get => _phone;
            set => _phone = value;
        }
            
            public string Password
        {
            set => _password = value;
        }

        public int Login(string username, string password)
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            users_folder = project_folder + "\\Users";
            user_file = users_folder + "\\" + username + ".txt";
            if (File.Exists(user_file))
            {
                LoadUserProfile(username);
                if (_password == password)
                {
                    return 0;
                }
                else
                { return 1; }
            }
            else
                return -1;
        }
        public void CreateNewUser(string card_number, string card_type, string name, string surname, string given_name, string date_of_birth, string login_email, string phone, string password)
        {
            _UAH_amount = 0;
            _USD_amount = 0;
            _EUR_amount = 0;
            _card_number = card_number;
            _Card_type = card_type;
            _name = name;
            _surname = surname;
            _Given_name = given_name;
            _date_of_birth = date_of_birth;
            _login_email = login_email;
            _phone = phone;
            _password = password;
            UpdateUserProfile(login_email);
        }

        public void UpdateUser(string username, string password)
        {
            _login_email = username;
            _password = password;
            UpdateUserProfile(username);
        }


        public void InitiateUser(string username)
        {
            LoadUserProfile(username);
        }

        public void TransferMoney(string recipient_username, string currency, int amount) //Totally potuzhno created function
        {

        }

        public int WithdrawMoney(string currency, int value)
        {
            int status = 1;
            switch (currency){
                case "UAH":
                    if(_UAH_amount - value >= 0)
                    {
                        _UAH_amount -= value;
                        status = 0;
                    }
                    break;
                case "USD":
                    if (_USD_amount - value >= 0)
                    {
                        _USD_amount -= value;
                        status = 0;
                    }
                    break;
                case "EUR":
                    if (_EUR_amount - value >= 0)
                    {
                        _EUR_amount -= value;
                        status = 0;
                    }
                    break;
            }
            UpdateUserProfile(_login_email);
            return status;
        }

        public void IngestMoney(string currency, int value)
        {
            switch (currency)
            {
                case "UAH":
                        _UAH_amount += value;
                    break;
                case "USD":
                        _USD_amount += value;
                    break;
                case "EUR":
                        _EUR_amount += value;
                    break;
            }
            UpdateUserProfile(_login_email);
        }

        public void DeleteAccount()
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            users_folder = project_folder + "\\Users";
            user_file = users_folder + "\\" + _login_email + ".txt";

            if (File.Exists(user_file))
            {
                File.Delete(user_file);
            }
        }

        #endregion

        #region InternalDataHandling
        private void LoadUserProfile(string username)
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            users_folder = project_folder + "\\Users";
            try
            {
                string file = users_folder + "\\" + username + ".txt";
                if (File.Exists(file))
                {
                    string NewData;
                    using (StreamReader DatabaseFetcher = new StreamReader(file))
                    {
                        while ((NewData = DatabaseFetcher.ReadLine()) != null)
                        {
                            UserData.Push(NewData);
                        }
                    }

                    _password = UserData.Pop();
                    _phone = UserData.Pop();
                    _login_email = UserData.Pop();
                    _date_of_birth = UserData.Pop();
                    _Given_name = UserData.Pop();
                    _surname = UserData.Pop();
                    _name = UserData.Pop();
                    _Card_type = UserData.Pop();
                    _card_number = UserData.Pop();
                    _EUR_amount = Convert.ToInt32(UserData.Pop());
                    _USD_amount = Convert.ToInt32(UserData.Pop());
                    _UAH_amount = Convert.ToInt32(UserData.Pop());
                    UserData.Clear();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("User profile corrupted, please contact admin or re-create your user");
            }
        }

        private void UpdateUserProfile(string username)
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            users_folder = project_folder + "\\Users";
            user_file = users_folder + "\\" + username + ".txt";

            if (File.Exists(user_file))
            {
                File.Delete(user_file);
            }
            string[] UserDataString = new string[12];
            UserDataString[0] = _UAH_amount.ToString();
            UserDataString[1] = _USD_amount.ToString();
            UserDataString[2] = _EUR_amount.ToString();
            UserDataString[3] = _card_number;
            UserDataString[4] = _Card_type;
            UserDataString[5] = _name;
            UserDataString[6] = _surname;
            UserDataString[7] = _Given_name;
            UserDataString[8] = _date_of_birth;
            UserDataString[9] = _login_email;
            UserDataString[10] = _phone;
            UserDataString[11] = _password;
            using (StreamWriter SensorData = new StreamWriter(user_file, false))
            {
                for (int i = 0; i < UserDataString.Length; i++)
                {
                    SensorData.WriteLine(UserDataString[i]);
                }

            }
        }
        #endregion

    }
}
