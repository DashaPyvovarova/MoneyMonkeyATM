﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace MoneyMonkeyATM.Class
{
    class ATM
    {
        private int _UAH_amount;
        private int _USD_amount;
        private int _EUR_amount;
        private int _max_UAH_amount = 100000;
        private int _max_USD_amount = 10000;
        private int _max_EUR_amount = 10000;

        private string ATMDataFolder = "ATMData";
        private string CurrencyInfoFile = "Currency.txt";
        private string LogsFile = "Logs.txt";
        private string SessionToken = "Session.token";

        private string _session;

        private string project_folder;
        private string ATM_info;

        private Stack<string> ATMData = new Stack<string>();
        private Stack<string> Logs = new Stack<string>();


        public void Atm_CreateInstance() //Crates the ViewServer instance
        {
            LoadATMFiles();
        }

        public void WithdrawMoney(string currency, int amount)
        {
            switch (currency)
            {
                case "UAH":
                    if (_UAH_amount - amount >= 0)
                    {
                        _UAH_amount -= amount;
                    }
                    break;
                case "USD":
                    if (_USD_amount - amount >= 0)
                    {
                        _USD_amount -= amount;
                    }
                    break;
                case "EUR":
                    if (_EUR_amount - amount >= 0)
                    {
                        _EUR_amount -= amount;
                    }
                    break;
                default:
                    break;

            }
            WriteATMFile();
        }

        public void IngestCurrency(string currency, int amount)
        {
            switch (currency)
            {
                case "UAH":
                    if (_UAH_amount + amount <= _max_UAH_amount)
                    {
                        _UAH_amount += amount; 
                    }
                break;
                case "USD":
                    if (_USD_amount + amount <= _max_USD_amount)
                    {
                        _USD_amount += amount;
                    }
                    break;
                case "EUR":
                    if (_EUR_amount + amount <= _max_EUR_amount)
                    {
                        _EUR_amount += amount;
                    }
                    break;
                default:
                    break;
            }
            WriteATMFile();
        }

        public void CreateLog(string log)
        {
            Logs.Push(DateTime.Now.ToString() + ": " + log);
            WriteLogs();
        }

        public string GetLog()
        {
            if (Logs.Count > 0)
            {
                string stlog = "";
                while(Logs.Count!= 0)
                {
                    stlog += Logs.Pop() + "\r\n";
                }
                return stlog;
            }
            else
            {
                ReadLogs();
                string stlog = "";
                while (Logs.Count != 0)
                {
                    stlog += Logs.Pop() + "\r\n";
                }
                return stlog;
            }
        }

        public void CreateSession(string username)
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            ATM_info = project_folder + "\\ATM";
            using (StreamWriter SensorData = new StreamWriter(ATM_info + "\\" + SessionToken, false))
            {            
                    SensorData.WriteLine(username);
            }

        }

        public string GetSession()
        {
            _session = "";
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            ATM_info = project_folder + "\\ATM";
            try
            {
                string file = ATM_info + "\\" + SessionToken;
                if (File.Exists(file))
                {
                    string NewData;
                    using (StreamReader ATMDataHandler = new StreamReader(file))
                    {             
                            _session = ATMDataHandler.ReadLine();
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Session token expired or never existed. \r\n Code 401 - unauthorized");
                return null;

            }
            if (_session.Length > 1)
            {
                return _session;
            }
            else
                return null;
        }

        public void ExpireSession() 
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            ATM_info = project_folder + "\\ATM";

            if (File.Exists(ATM_info + "\\" + SessionToken))
            {
                File.Delete(ATM_info + "\\" + SessionToken);
            }
        }

        public int UAH_Amount
        {
            get => _UAH_amount;

        }

        public int USD_Amount
        {
            get => _USD_amount;

        }
        public int EUR_Amount
        {
            get => _EUR_amount;
        }

        public int max_UAH_Amount
        {
            get => _max_UAH_amount;
        }

        public int max_USD_Amount
        {
            get => _max_USD_amount;
        }
        public int max_EUR_Amount
        {
            get => _max_EUR_amount;
        }


        #region InternalDataHandling

        private void LoadATMFiles()
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            ATM_info = project_folder + "\\ATM";
            if (File.Exists(ATM_info + "\\" + CurrencyInfoFile))
            {
                ReadATMFile();
                ReadLogs();
            }
        }

        private void ReadATMFile()
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            ATM_info = project_folder + "\\ATM";
            try
            {
                string file = ATM_info + "\\" + CurrencyInfoFile;
                if (File.Exists(file))
                {
                    string NewData;
                    using (StreamReader ATMDataHandler = new StreamReader(file))
                    {
                        while ((NewData = ATMDataHandler.ReadLine()) != null)
                        {
                            ATMData.Push(NewData);
                        }
                    }

                    _max_EUR_amount = Convert.ToInt32(ATMData.Pop());
                    _max_USD_amount = Convert.ToInt32(ATMData.Pop());
                    _max_UAH_amount = Convert.ToInt32(ATMData.Pop());
                    _EUR_amount = Convert.ToInt32(ATMData.Pop());
                    _USD_amount = Convert.ToInt32(ATMData.Pop());
                    _UAH_amount = Convert.ToInt32(ATMData.Pop());
                    ATMData.Clear();
                }
            }
            catch (Exception ex)
            {
              
            }
        }

        private void WriteATMFile()
        {
            project_folder = Environment.GetFolderPath(Environment.SpecialFolder.Personal) + "\\Money Monkey ATM";
            ATM_info = project_folder + "\\ATM";
            File.Delete(ATM_info + "\\" + CurrencyInfoFile);
            string[] ATMCurrencies = new string[6];
            ATMCurrencies[0] = _UAH_amount.ToString();
            ATMCurrencies[1] = _USD_amount.ToString();
            ATMCurrencies[2] = _EUR_amount.ToString();
            ATMCurrencies[3] = _max_UAH_amount.ToString();
            ATMCurrencies[4] = _max_USD_amount.ToString();
            ATMCurrencies[5] = _max_EUR_amount.ToString();
            using (StreamWriter SensorData = new StreamWriter(ATM_info + "\\" + CurrencyInfoFile, false))
            {
                for (int i = 0; i < ATMCurrencies.Length; i++)
                {
                    SensorData.WriteLine(ATMCurrencies[i]);
                }

            }
        }

        private void ReadLogs()
        {
            try
            {
                string file = ATM_info + "\\" + LogsFile;
                if (File.Exists(file))
                {
                    string NewData;
                    using (StreamReader LogsHandler = new StreamReader(file))
                    {
                        while ((NewData = LogsHandler.ReadLine()) != null)
                        {
                            Logs.Push(NewData);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void WriteLogs()
        {
            File.Delete(ATM_info + "\\" + LogsFile);
            using (StreamWriter LogsWriter = new StreamWriter(ATM_info + "\\" + LogsFile, false))
            {
                while (Logs.Count != 0)
                {
                    LogsWriter.WriteLine(Logs.Pop());
                }
                }

            }
        }
        #endregion
}
